# Trading Bot (Binance Futures Testnet)

## Features
- Market Orders
- Limit Orders
- Stop-Limit Orders (Bonus)
- CLI-based interface
- Logging & validation

## Setup
pip install -r requirements.txt

## Usage
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

## Logs
Check bot.log file

## Bonus
Stop-Limit Order implemented
