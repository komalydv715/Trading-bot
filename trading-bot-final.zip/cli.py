import argparse
import logging
from bot.orders import place_market_order, place_limit_order, place_stop_limit_order
from bot.validators import *
from bot.logging_config import setup_logging

setup_logging()

parser = argparse.ArgumentParser(description="Trading Bot CLI")

parser.add_argument("--symbol", required=True)
parser.add_argument("--side", required=True)
parser.add_argument("--type", required=True)
parser.add_argument("--quantity", type=float, required=True)
parser.add_argument("--price", type=float)
parser.add_argument("--stop_price", type=float)

args = parser.parse_args()

try:
    validate_side(args.side)
    validate_order_type(args.type)
    validate_quantity(args.quantity)

    if args.type.upper() == "MARKET":
        res = place_market_order(args.symbol, args.side, args.quantity)

    elif args.type.upper() == "LIMIT":
        if not args.price:
            raise ValueError("Price required for LIMIT order")
        res = place_limit_order(args.symbol, args.side, args.quantity, args.price)

    elif args.type.upper() == "STOP":
        if not args.price or not args.stop_price:
            raise ValueError("Price and stop_price required for STOP order")
        res = place_stop_limit_order(args.symbol, args.side, args.quantity, args.price, args.stop_price)

    print("\n========== ORDER SUMMARY ==========")
    print(f"Symbol   : {args.symbol}")
    print(f"Side     : {args.side}")
    print(f"Type     : {args.type}")
    print(f"Quantity : {args.quantity}")

    if args.price:
        print(f"Price    : {args.price}")
    if args.stop_price:
        print(f"StopPrice: {args.stop_price}")

    print("\nOrder Placed Successfully")
    print("Order ID:", res.get("orderId"))
    print("Status  :", res.get("status"))

    logging.info(f"Order Success: {res}")

except Exception as e:
    print("\nError:", str(e))
    logging.error(str(e))
