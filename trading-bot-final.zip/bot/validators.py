def validate_side(side):
    if side.upper() not in ["BUY", "SELL"]:
        raise ValueError("Side must be BUY or SELL")

def validate_order_type(order_type):
    if order_type.upper() not in ["MARKET", "LIMIT", "STOP"]:
        raise ValueError("Type must be MARKET, LIMIT, or STOP")

def validate_quantity(qty):
    if qty <= 0:
        raise ValueError("Quantity must be positive")
