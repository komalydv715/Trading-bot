from bot.client import get_client
import logging

client = get_client()

def place_market_order(symbol, side, quantity):
    logging.info(f"Placing MARKET order: {symbol} {side} {quantity}")
    return client.futures_create_order(
        symbol=symbol,
        side=side,
        type="MARKET",
        quantity=quantity
    )

def place_limit_order(symbol, side, quantity, price):
    logging.info(f"Placing LIMIT order: {symbol} {side} {quantity} @ {price}")
    return client.futures_create_order(
        symbol=symbol,
        side=side,
        type="LIMIT",
        quantity=quantity,
        price=price,
        timeInForce="GTC"
    )

def place_stop_limit_order(symbol, side, quantity, price, stop_price):
    logging.info("Placing STOP-LIMIT order")
    return client.futures_create_order(
        symbol=symbol,
        side=side,
        type="STOP",
        quantity=quantity,
        price=price,
        stopPrice=stop_price,
        timeInForce="GTC"
    )
